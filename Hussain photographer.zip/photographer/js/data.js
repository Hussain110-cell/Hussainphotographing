mainData = [
    { 
      id: 1,
      type: "Photos",
      src: 'img/gallery/1.jpg',
      tum: 'img/gallery/1.jpg',
      cp: "2019 Nature"
    },
    { 
      id: 2,
      type: "Photos",
      src: 'img/gallery/2.jpg',
      tum: 'img/gallery/2.jpg',
      cp: "2020 Sky"
    },
    { 
      id: 3,
      type: "Photos",
      src: 'img/gallery/3.jpg',
      tum: 'img/gallery/3.jpg',
      cp: "Under The Sea"
    },
    { 
      id: 4,
      type: "Design",
      src: 'img/gallery/4.jpg',
      tum: 'img/gallery/4.jpg',
      cp: "Hello, candy"
    },
    { 
      id: 5,
      type: "Photos",
      src: 'img/gallery/5.jpg',
      tum: 'img/gallery/5.jpg',
      cp: "Amazing! 2001"
    },
    { 
      id: 6,
      type: "Photos",
      src: 'img/gallery/6.jpg',
      tum: 'img/gallery/6.jpg',
      cp: "Amazing! 2017"
    },
    { 
      id: 7,
      type: "Design",
      src: 'img/gallery/7.jpg',
      tum: 'img/gallery/7.jpg',
      cp: "Nice Photo"
    },
    { 
      id: 8,
      type: "Photos",
      src: 'img/gallery/8.jpg',
      tum: 'img/gallery/8.jpg',
      cp: "Nice Photo"
    },
    { 
      id: 9,
      type: "Photos",
      src: 'img/gallery/9.jpg',
      tum: 'img/gallery/9.jpg',
      cp: "Nice Photo"
    },{ 
      id: 10,
      type: "Design",
      src: 'img/gallery/10.jpg',
      tum: 'img/gallery/10.jpg',
      cp: "Nice Photo"
    },{ 
      id: 11,
      type: "Design",
      src: 'img/gallery/11.jpg',
      tum: 'img/gallery/11.jpg',
      cp: "Nice Photo"
    },
    { 
      id: 12,
      type: "Photoshop",
      src: 'img/gallery/12.jpg',
      tum: 'img/gallery/12.jpg',
      cp: "Nice Photo"
    },
    { 
      id: 13,
      type: "Photos",
      src: 'img/gallery/13.jpg',
      tum: 'img/gallery/13.jpg',
      cp: "Nice Photo"
    },
    { 
      id: 14,
      type: "Photos",
      src: 'img/gallery/14.jpg',
      tum: 'img/gallery/14.jpg',
      cp: "Nice Photo"
    },
    { 
      id: 15,
      type: "Photoshop",
      src: 'img/gallery/15.jpg',
      tum: 'img/gallery/15.jpg',
      cp: "Nice Photo"
    },
    { 
      id: 16,
      type: "Photos",
      src: 'img/gallery/16.jpeg',
      tum: 'img/gallery/16.jpeg',
      cp: "Nice Photo"
    },
    { 
      id: 17,
      type: "Photos",
      src: 'img/gallery/17.jpeg',
      tum: 'img/gallery/17.jpeg',
      cp: "Nice Photo"
    },
    { 
      id: 18,
      type: "Photos",
      src: 'img/gallery/18.jpeg',
      tum: 'img/gallery/18.jpeg',
      cp: "Nice Photo"
    },
    { 
      id: 19,
      type: "Photoshop",
      src: 'img/gallery/19.jpg',
      tum: 'img/gallery/19.jpg',
      cp: "Nice Photo"
    },
    { 
      id: 20,
      type: "Photoshop",
      src: 'img/gallery/20.jpeg',
      tum: 'img/gallery/20.jpeg',
      cp: "Nice Photo"
    },
    { 
      id: 21,
      type: "Photoshop",
      src: 'img/gallery/21.jpg',
      tum: 'img/gallery/21.jpg',
      cp: "Nice Photo"
    },
    { 
      id: 22,
      type: "Photoshop",
      src: 'img/gallery/22.jpg',
      tum: 'img/gallery/22.jpg',
      cp: "Nice Photo"
    }
  ];